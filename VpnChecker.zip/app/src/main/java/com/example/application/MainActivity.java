package com.example.application;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;
import android.view.View.OnClickListener;
import android.view.View;
import org.json.JSONException;

public class MainActivity extends AppCompatActivity {
	
	TextView textView;
	Button btnRequest1,btnRequest2,btnRequest3;
	
	JsonObjectRequest request1,request2,request3;
	RequestQueue queue;
	
	String url = "https://api.ipify.org/?format=json";
	String url2 = "https://api.myip.com";
	String url3 = "https://api.my-ip.io/v2/ip.json";
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		
		textView = findViewById(R.id.activitymainTextView1);
		btnRequest1 = findViewById(R.id.activitymainButton1);
		btnRequest2 = findViewById(R.id.activitymainButton2);
		btnRequest3 = findViewById(R.id.activitymainButton3);
		
		queue = Volley.newRequestQueue(this);
		
		request1 = new JsonObjectRequest
        (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

				@Override
				public void onResponse(JSONObject response) {
					try {
						textView.setText("ip : " + response.getString("ip"));
					} catch (JSONException e) {
						textView.setText("Response: " + e.getMessage().toString());
					}
				}
			}, new Response.ErrorListener() {

				@Override
				public void onErrorResponse(VolleyError error) {
					textView.setText(error.getMessage());
				}
			});
			
		request2 = new JsonObjectRequest
        (Request.Method.GET, url2, null, new Response.Listener<JSONObject>() {

				@Override
				public void onResponse(JSONObject response) {
					try {
						StringBuilder sb = new StringBuilder();
						sb.append("ip : ").append(response.getString("ip")).append("\n");
						sb.append("country : ").append(response.getString("country")).append("\n");
						sb.append("cc : ").append(response.getString("cc"));
						textView.setText(sb.toString());
					} catch (JSONException e) {
						textView.setText("Response: " + e.getMessage());
					}
				}
			}, new Response.ErrorListener() {

				@Override
				public void onErrorResponse(VolleyError error) {
					textView.setText(error.getMessage());
				}
			});
			
		request3 = new JsonObjectRequest
        (Request.Method.GET, url3, null, new Response.Listener<JSONObject>() {

				@Override
				public void onResponse(JSONObject response) {
					try {
						StringBuilder sb = new StringBuilder();
						sb.append("success : ").append(response.getBoolean("success")).append("\n");
						sb.append("ip : ").append(response.getString("ip")).append("\n");
						sb.append("type : ").append(response.getString("type")).append("\n");
						sb.append("country : ").append(response.getJSONObject("country").toString()).append("\n");
						sb.append("location : ").append(response.getJSONObject("location").toString()).append("\n");
						sb.append("timezone : ").append(response.getString("timeZone")).append("\n");
						sb.append("asn : ").append(response.getJSONObject("asn").toString());
						
						
						textView.setText(sb.toString());
					} catch (JSONException e) {
						textView.setText("Response: " + e.getMessage());
					}
				}
			}, new Response.ErrorListener() {

				@Override
				public void onErrorResponse(VolleyError error) {
					textView.setText(error.getMessage());
				}
			});
			
		btnRequest1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					queue.add(request1);
				}
			});
			
		btnRequest2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					queue.add(request2);
				}
			});
			
		btnRequest3.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					queue.add(request3);
				}
			});
			
    }
    
}
